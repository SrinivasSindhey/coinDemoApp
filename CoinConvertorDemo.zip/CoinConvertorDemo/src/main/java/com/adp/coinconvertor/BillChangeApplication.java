package com.adp.coinconvertor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillChangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillChangeApplication.class, args);
	}

}
