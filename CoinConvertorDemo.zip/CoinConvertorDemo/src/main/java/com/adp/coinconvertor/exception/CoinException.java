package com.adp.coinconvertor.exception;

public class CoinException extends Exception {

	private String errorMessage = "";
	
	public CoinException(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
